import greenfoot.*;

public class Player extends Actor {
    int _idleImageNum = 5;
    int _walksImageNum = 7;
    int _NitroImageNum = 4;
    String state = "idle";

    private int normalSpeed = 2;
    private int fastSpeed = 3;

    private int nitroSpeed = 20; // Kecepatan Nitro

    public String getState() {
        return this.state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Player() {
        this.setImage(new GreenfootImage("/player/idle/0.png"));
    }

    int _animationDelay = 10;
    int _animationTimer = 0;
    int _lastSpriteNo = 0;
    boolean moveForward = true;

    void animate() {
        if (_animationTimer < _animationDelay) {
            _animationTimer++;
            return;
        }

        _animationTimer = 0;
        String path = "";
        switch (this.state) {
            case "idle":
                path = "/player/idle/" + _lastSpriteNo % _idleImageNum + ".png";
                break;
            case "walks":
                path = "/player/walks/" + _lastSpriteNo % _walksImageNum + ".png";
                break;
            case "Nitro":
                path = "/player/Nitro/" + _lastSpriteNo % _NitroImageNum + ".png";
                break;
            default:
                path = "/player/walks/";
                break;
        }

        this.setImage(new GreenfootImage(path));
        _lastSpriteNo++;
        GreenfootImage img = new GreenfootImage(path);

        if (!moveForward) {
            img.mirrorHorizontally();
        }

        this.setImage(img);
    }

    void controlPlayer() {
        int speed = normalSpeed; // Kecepatan normal

        if (Greenfoot.isKeyDown("shift")) {
            state = "Nitro";
            speed = nitroSpeed; // Menggunakan kecepatan Nitro jika tombol "Shift" ditekan
        } else {
            state = "idle";
        }

        if (Greenfoot.isKeyDown("right")) {
            moveForward = true;
            state = "walks";
            state = "Nitro";
            setLocation(getX() + speed, getY());
        } else if (Greenfoot.isKeyDown("left")) {
            moveForward = false;
            state = "walks";
            state = "Nitro";
            setLocation(getX() - speed, getY());
        }
    }

    public void act() {
        controlPlayer();
        animate();
    }
}